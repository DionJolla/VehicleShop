package org.makerminds.jcoaching.finalexam.model;

/**
 * enumeration for fuel type.
 * 
 * @author <Dion-Jolla>
 *
 */
public enum FuelType {
	DIESEL, PETROL
}

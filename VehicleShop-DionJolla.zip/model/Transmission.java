package org.makerminds.jcoaching.finalexam.model;

/**
 * enumeration for transmission.
 * 
 * @author <Dion-Jolla>
 *
 */
public enum Transmission {
	AUTOMATIC, MANUAL
}

package org.makerminds.jcoaching.finalexam.model;

/**
 * enumeration for manufacturer.
 * 
 * @author <Dion-Jolla>
 *
 */
public enum Manufacturer {
	AUDI, BMW, VW, SKODA, HONDA
}

package org.makerminds.jcoaching.finalexam.model;

/**
 * enumeration for color type.
 * 
 * @author <Dion-Jolla>
 *
 */
public enum Color {
	BLACK, WHITE, RED, YELLOW, GREY, BLUE, BROWN
}
package org.makerminds.jcoaching.finalexam.controller;

import java.util.Iterator;
import java.util.List;

import org.makerminds.jcoaching.finalexam.model.Vehicle;

/**
 * responsible for processing business processes.
 * 
 * @author <Dion-Jolla>
 *
 */

public class VehicleShopProcessor {

	public void sellVehicle(List<Vehicle> vehiclesList, int vehicleChosenId) {

		Iterator<Vehicle> iterator = vehiclesList.iterator();
		while (iterator.hasNext()) {
			Vehicle vehicle = iterator.next();
			int id = vehicle.getId();
			if (id == vehicleChosenId) {
				iterator.remove();
			}
		}
	}
}
/**
 * searches for the vehicle with the specified ID and marks it as sold
 * 
 * @param vehicles the list of vehicles
 * @param idToSell the ID of the vehicle to sell
 */

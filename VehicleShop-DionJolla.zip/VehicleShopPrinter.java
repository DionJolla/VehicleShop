package org.makerminds.jcoaching.finalexam.controller;

import java.util.List;

import org.makerminds.jcoaching.finalexam.model.Vehicle;

/**
 * responsible for printing vehicle shop data.
 * 
 * @author <Dion-Jolla>
 *
 */
public class VehicleShopPrinter {

	public void printAvailableVehicles(List<Vehicle> vehicleList) {
		System.out.println("Available Vehicles:");
		for (Vehicle vehicle : vehicleList) {
			System.out.println("ID: " + vehicle.getId() + ", Manufacturer: " + vehicle.getManufacturer() + ", Model: "
					+ vehicle.getModel() + ", Horsepower: " + vehicle.getHorsePower() + ", Price: " + vehicle.getPrice()
					+ ", Color: " + vehicle.getColor() + ", Mileage: " + vehicle.getMileage() + ", Year: "
					+ vehicle.getProductYear() + ", Transmission: " + vehicle.getTransmission() + ", Fuel Type: "
					+ vehicle.getFuelType());
		}
	}

	public void printVehicleSoldMessage(int vehicleChosenId) {
		// \n in a String will cause a line break
		System.out.println("\n" + "Vehicle with ID " + vehicleChosenId + " was sold.");
	}

	public void printVehicleIdToSellRequest() {
		// \n in a String will cause a line break
		System.out.println("\n\n Please enter the number (ID) of the vehicle you want to sell: ");
	}
}

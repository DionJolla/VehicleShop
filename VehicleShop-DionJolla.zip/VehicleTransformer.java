package org.makerminds.jcoaching.finalexam.controller;

import java.util.List;
import java.util.ArrayList;

import org.makerminds.jcoaching.finalexam.model.Color;
import org.makerminds.jcoaching.finalexam.model.FuelType;
import org.makerminds.jcoaching.finalexam.model.Manufacturer;
import org.makerminds.jcoaching.finalexam.model.Transmission;
import org.makerminds.jcoaching.finalexam.model.Vehicle;

/**
 * * @author <Dion-jolla> responsible for transforming vehicle data into
 * {@link Vehicle} objects.
 * 
 *
 */
public class VehicleTransformer {

	/**
	 * transforms a data array into a {@link Vehicle} list
	 * 
	 * @param vehicle data array
	 * @return list of {@link Vehicle} objects
	 */
	public List<Vehicle> transformDataArrayToVehicleObjects(List<String> vehicleDataArray) {
		List<Vehicle> vehicleList = new ArrayList<>();

		for (String vehicleData : vehicleDataArray) {
			Vehicle vehicle = transformToVehicleObject(vehicleData);
			if (vehicle != null) {
				vehicleList.add(vehicle);
			}
		}

		return vehicleList;
	}

	/**
	 * transforms a vehicle data record as String into a {@link Vehicle} object
	 * 
	 * @param vehicle data record as String
	 * @return {@link Vehicle} object
	 */
	private Vehicle transformToVehicleObject(String vehicleAsString) {
		String[] dataParts = vehicleAsString.split(",");
		if (dataParts.length != 10) {
			System.out.println("Error: Incorrect data format for vehicle: " + vehicleAsString);
			return null;
		}

		Vehicle vehicle = new Vehicle();
		vehicle.setId(Integer.parseInt(dataParts[0].trim()));
		vehicle.setManufacturer(Manufacturer.valueOf(dataParts[1].trim()));
		vehicle.setModel(dataParts[2].trim());
		vehicle.setHorsePower(Integer.parseInt(dataParts[3].trim()));
		vehicle.setPrice(Double.parseDouble(dataParts[4].trim()));
		vehicle.setColor(Color.valueOf(dataParts[5].trim()));
		vehicle.setMileage(Integer.parseInt(dataParts[6].trim()));
		vehicle.setProductYear(Integer.parseInt(dataParts[7].trim()));
		vehicle.setFuelType(FuelType.valueOf(dataParts[8].trim()));
		vehicle.setTransmission(Transmission.valueOf(dataParts[9].trim()));

		return vehicle;
	}
}
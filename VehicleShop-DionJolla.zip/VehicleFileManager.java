package org.makerminds.jcoaching.finalexam.controller;
import java.io.IOException; 
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;

import org.makerminds.jcoaching.finalexam.model.Vehicle;

/**
 * managing the file.
 * 
 * @author <Dion-Jolla>
 *
 */
public class VehicleFileManager {
	
	private String filePath;
	
	public VehicleFileManager(String filePath) {
		this.filePath = filePath;
	}
	
	public List<String> importVehiclesFromFile() {
	    try {
	    	//Path myPath = Paths.get("src/main/resources/vehicle-list.txt");
            return Files.readAllLines(Paths.get(getClass().getResource(filePath).toURI()));
	    } catch (IOException | URISyntaxException e) {
	        throw new RuntimeException("An error occurred", e);
	    }
	}
	
	public void rewriteFile(List<Vehicle> vehicleList) {
		StringBuffer VehicleStringRewrite = new  StringBuffer();
		Iterator<Vehicle> iterator = vehicleList.iterator();
		while (iterator.hasNext()) {
			Vehicle vehicle = iterator.next();
			prepareTheVehicleForRewriting(VehicleStringRewrite, vehicle);
			VehicleStringRewrite.append("\r\n");
		}
		try {
			Path path = Paths.get(getClass().getResource(filePath).toURI());
			Files.writeString(path, VehicleStringRewrite.toString());
		} catch (IOException | URISyntaxException e ) {
			e.printStackTrace();
		}

		}
		
	private void prepareTheVehicleForRewriting(StringBuffer sb, Vehicle vehicle) {
	    sb.append(vehicle.getId());
	    sb.append(",");
	    sb.append(vehicle.getManufacturer().name());
	    sb.append(",");
	    //manufacturer
	    sb.append(vehicle.getModel());
	    sb.append(",");
	    sb.append(vehicle.getHorsePower());
	    sb.append(",");
	    sb.append(vehicle.getPrice());
	    sb.append(",");
	    sb.append(vehicle.getColor());
	    sb.append(",");
	    sb.append(vehicle.getMileage());
	    sb.append(",");
	    sb.append(vehicle.getProductYear());
	    sb.append(",");
	    sb.append(vehicle.getFuelType().name());
	    sb.append(",");
	    sb.append(vehicle.getTransmission().name());
	}
}